# Lessons Learned

Patterns to remember. Updated after each correction.

---

## 1. Never use `allow_origins=["*"]` with `allow_credentials=True`

**Date:** 2026-03-28
**Context:** CORS middleware in FastAPI

The CORS spec explicitly says: wildcard origins + credentials = rejected by
browsers.  Even if it "worked," any random site could make authenticated
requests to your API.

**Rule:** Always restrict origins to a configurable list.  Use env vars
for production overrides.

---

## 2. Conditional routing prevents silent garbage

**Date:** 2026-03-28
**Context:** LangGraph pipeline had unconditional `add_edge` everywhere

If node A fails and returns `add_error()`, the graph still marched to nodes
B, C, D, and generated a memo from empty data.  The output looked complete
but was hallucinated.

**Rule:** After each data-gathering node, a router checks `has_fatal_error()`.
Fatal → skip to memo.  Recoverable → continue.  The memo node checks
`get_data_availability()` and tells the LLM what's missing.

---

## 3. Build citation registries BEFORE the LLM call

**Date:** 2026-03-28
**Context:** "Fake citations" — LLM told to use [1], [2] but indices
were assigned independently

The old code told the LLM "include citation numbers [1], [2]" then built
a separate numbered list afterwards, hoping the LLM's numbers matched the
list's numbers.  They often didn't.

**Rule:**
1. Build a `registry` with numbered sources before calling the LLM
2. Include the registry in the prompt ("Available Sources [1] = Reuters…")
3. After generation, extract used indices and verify against the registry
4. Log orphan citations (indices the LLM invented)

---

## 4. Don't duplicate constants across modules

**Date:** 2026-03-28
**Context:** `CANONICAL_SECTIONS` and `SECTION_ALIASES` defined independently
in both `rag/ingestion.py` and `rag/vector_store.py`

When you add a new alias in one file and forget the other, you get silent
retrieval failures.

**Rule:** Single source of truth.  Created `rag/sections.py`.
Both modules import from it.

---

## 5. `sys.path.insert(0, ...)` is a packaging failure

**Date:** 2026-03-28
**Context:** Every production file had `sys.path.insert(0, str(Path(...)))`

This hack means the project was never properly installed.
It breaks IDE navigation, mypy, and import resolution in CI.

**Rule:** Use `pip install -e .` during development.  Ensure `pyproject.toml`
lists all packages in `[tool.hatch.build.targets.wheel]`.  Never touch
`sys.path` in production code.

---

## 6. Dead code has negative value

**Date:** 2026-03-28
**Context:** `EmbeddingsClient`, `embed_texts_async`, `search_filings()`,
`run_agent_sync()`, and every `_main()` block

100+ lines of code that nothing called.  It creates cognitive load, gives
false confidence ("we have an async path!"), and rots because nobody tests it.

**Rule:** If nothing calls it and there's no concrete plan to call it within
the current phase, delete it.  Git remembers.

Exception: `EmbeddingsClient` and `run_agent_sync()` were kept because they
have concrete near-term use (Qdrant migration, CLI scripts).

---

## 7. Module-level singletons are testing poison

**Date:** 2026-03-28
**Context:** `_default_store: Optional[ChromaDBVectorStore] = None` at
module level in vector_store.py

You can't swap the store in tests without monkeypatching.

**Rule:** Use FastAPI `Depends()` for API endpoints (tests override via
`app.dependency_overrides`).  For non-FastAPI code, provide a
`reset_vector_store()` function for test teardown.

---

## 8. Retry external calls — but make retry optional

**Date:** 2026-03-28
**Context:** SEC EDGAR, Tavily, yfinance — all called with no retry/timeout

One slow SEC response blocks the entire pipeline.

**Rule:** Use tenacity with exponential backoff.  But make it a no-op if
tenacity isn't installed, so the core code doesn't hard-crash on a missing
optional dependency.

---

## 9. `_main()` blocks belong in test files, not production modules

**Date:** 2026-03-28
**Context:** Every module had `if __name__ == "__main__": asyncio.run(_main())`

These are manual smoke tests disguised as production code.  They're never
run in CI, they often break (the graph.py one referenced a nonexistent
`cite['source_type']` key), and they add noise.

**Rule:** Smoke-test logic belongs in `tests/unit/test_<module>.py` with
proper mocking so it runs in CI.  Production modules should be clean.

---

## 10. Version-bump when you make breaking changes

**Date:** 2026-03-28
**Context:** API response schema changed (citation key `source_type` → `type`)

If you change the shape of your API response, consumers break silently.

**Rule:** Bump the version in `pyproject.toml` and the `/health` endpoint.
Even for internal APIs.
