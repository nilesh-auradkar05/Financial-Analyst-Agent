# Alpha Analyst — Hardening Refactor Plan

## Status: COMPLETE (all 16 items)

---

## Pre-done (by user)
- [x] 1. Fix typos: `Optinal` → `Optional`, citation key alignment
- [x] 4. Delete `src/financial_analyst_system/`
- [x] 5. Move `test_files/dog_on_beach.jpg` → `vlm_test_image/`

## Completed
- [x] 2. CORS restricted to configurable origins
- [x] 3. Graceful degradation via conditional routing
- [x] 6. `EmbeddingsClient` wired as public async API
- [x] 7. `embed_texts_async` / `embed_query_async` kept as public API
- [x] 8. `search_filings()` killed — zero-value wrapper
- [x] 9. `run_agent_sync()` kept — legitimate CLI use
- [x] 10. All `_main()` blocks removed → proper test files
- [x] 11. Shared constants extracted to `rag/sections.py`
- [x] 12. All `sys.path.insert` hacks removed
- [x] 13. Citation registry pattern — grounded, not decorative
- [x] 14. Retry/timeout via tenacity on all external calls
- [x] 15. DI for vector store via FastAPI `Depends()`
- [x] 16. CI/CD via `.github/workflows/ci.yml`

## Verification
- [x] All 15 production modules import cleanly
- [x] 120/120 unit tests pass
- [x] Zero `sys.path.insert` in production code
- [x] Zero `_main()` blocks in production code
- [x] `agents/__init__.py` cleaned of dead CrewAI imports
- [x] `pyproject.toml`: crewai removed, tenacity added, version bumped to 1.2.0

---

## NEXT: Context engineering for memo generation
- [ ] Replace flat `get_context_for_llm()` string with structured evidence
- [ ] Wire `EvidencePacket` into memo generation pipeline
- [ ] Separate reasoning context from final prose output
